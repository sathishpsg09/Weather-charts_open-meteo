'use client';

import React from 'react';
import Chart from 'react-apexcharts';
import { Thermometer, Wind, Droplets, Eye, Sun, Moon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTheme } from "next-themes";

const generateHourlyData = (baseValue, variance) => {
  return Array.from({ length: 24 }, (_, i) => {
    return {
      x: `${i}:00`,
      y: Number((baseValue + Math.random() * variance - variance / 2).toFixed(1))
    };
  });
};

const WeatherMetricCard = ({ title, value, baseValue, variance, icon: Icon, color, unit }) => {
  const [hoveredValue, setHoveredValue] = React.useState(null);
  const { theme } = useTheme();
  const data = React.useMemo(
    () => generateHourlyData(baseValue, variance),
    [baseValue, variance]
  );

  const chartOptions = {
    chart: {
      type: 'area',
      toolbar: { show: false },
      sparkline: {
        enabled: false
      },
      animations: {
        enabled: true,
        easing: 'easeinout',
        speed: 800,
      },
      events: {
        mouseMove: function(event, chartContext, config) {
          if (config.dataPointIndex !== -1) {
            const value = data[config.dataPointIndex].y;
            setHoveredValue(`${value}${unit}`);
          }
        },
        mouseLeave: function() {
          setHoveredValue(null);
        }
      },
      background: 'transparent'
    },
    colors: [color],
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.45,
        opacityTo: 0.05,
        stops: [0, 100]
      }
    },
    grid: {
      show: true,
      borderColor: theme === 'dark' ? '#2D3748' : '#f3f4f6',
      strokeDashArray: 3,
      xaxis: {
        lines: { show: false }
      }
    },
    stroke: {
      curve: 'smooth',
      width: 2
    },
    tooltip: {
      custom: function({ series, seriesIndex, dataPointIndex }) {
        const value = series[seriesIndex][dataPointIndex];
        const time = data[dataPointIndex].x;
        return `
          <div class="${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'} p-2 rounded-lg shadow-lg border">
            <div class="text-sm opacity-75">${time}</div>
            <div class="text-lg font-bold">${value}${unit}</div>
          </div>
        `;
      }
    },
    xaxis: {
      categories: data.map(d => d.x),
      labels: {
        show: true,
        style: {
          colors: theme === 'dark' ? '#CBD5E0' : '#6B7280',
          fontSize: '12px'
        }
      },
      axisBorder: { show: false },
      axisTicks: { show: false }
    },
    yaxis: {
      show: false
    },
    dataLabels: {
      enabled: false
    }
  };

  const series = [{
    name: title,
    data: data.map(d => d.y)
  }];

  return (
    <Card className="hover:shadow-lg transition-all duration-300">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">
          <div className="flex items-center gap-2">
            <Icon className="h-4 w-4" strokeWidth={2.5} />
            <span>{title}</span>
          </div>
        </CardTitle>
        <span className="text-2xl font-bold">
          {hoveredValue ? hoveredValue : value}
        </span>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-[200px] w-full">
          <Chart
            options={chartOptions}
            series={series}
            type="area"
            height="100%"
          />
        </div>
      </CardContent>
    </Card>
  );
};

const ThemeToggle = () => {
  const { theme, setTheme } = useTheme();
  
  return (
    <Button
      variant="outline"
      size="icon"
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      className="w-9 h-9"
    >
      <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
      <span className="sr-only">Toggle theme</span>
    </Button>
  );
};

const WeatherDashboard = () => {
  const { theme } = useTheme();
  
  const metrics = [
    {
      title: "Temperature",
      value: "24.5°C",
      baseValue: 24.5,
      variance: 5,
      icon: Thermometer,
      color: theme === 'dark' ? "#f87171" : "#ff7e67",
      unit: "°C"
    },
    {
      title: "Wind Speed",
      value: "12 km/h",
      baseValue: 12,
      variance: 8,
      icon: Wind,
      color: theme === 'dark' ? "#60a5fa" : "#4299e1",
      unit: " km/h"
    },
    {
      title: "Precipitation",
      value: "65%",
      baseValue: 65,
      variance: 30,
      icon: Droplets,
      color: theme === 'dark' ? "#4ade80" : "#68d391",
      unit: "%"
    },
    {
      title: "Visibility",
      value: "8.5 km",
      baseValue: 8.5,
      variance: 3,
      icon: Eye,
      color: theme === 'dark' ? "#a78bfa" : "#805ad5",
      unit: " km"
    }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Weather Dashboard</h1>
        <ThemeToggle />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {metrics.map((metric) => (
          <WeatherMetricCard key={metric.title} {...metric} />
        ))}
      </div>
    </div>
  );
};

export default WeatherDashboard;